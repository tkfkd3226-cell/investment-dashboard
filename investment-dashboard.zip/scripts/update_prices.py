#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""KRX 가격과 성과 스냅샷을 갱신하는 GitHub Actions용 스크립트.

운영 원칙:
- ``prices.json``과 ``performance_snapshots.json``만 갱신한다.
- ``--date``가 있으면 해당 날짜가 실제 KRX 거래일인지 확인한 뒤 그 거래일의 종목 가격·성과 스냅샷을 갱신한다.
- 이후 지정일까지 이미 저장된 날짜의 KOSPI 값은 누락·정정 여부를 확인해 backfill할 수 있다.
- ``--date``가 없으면 최신·누락·장중 재확정 대상을 자동 계산한다.
- KOSPI 지수는 pykrx → Naver → Yahoo 순서로 fallback 한다.

함수는 아래 순서로 배치한다.
설정/공통 helper → 시장 데이터 조회 → 대상일 계산 → 포트폴리오 계산 → 저장/CLI.
"""

from __future__ import annotations

import argparse
import json
import re
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import requests
from pykrx import stock

# ---------------------------------------------------------------------------
# Repository paths / runtime constants
# ---------------------------------------------------------------------------

ROOT = Path(__file__).resolve().parents[1]
PORTFOLIO_PATH = ROOT / "data" / "portfolio.json"
PRICES_PATH = ROOT / "data" / "prices.json"
SNAPSHOTS_PATH = ROOT / "data" / "performance_snapshots.json"

KST = timezone(timedelta(hours=9))
DATE_FORMAT = "%Y-%m-%d"
KOSPI_INDEX_TICKER = "1001"
DEFAULT_LOOKBACK_DAYS = 7
FETCH_RETRIES = 2
FETCH_RETRY_DELAY_SECONDS = 1.5
HTTP_TIMEOUT_SECONDS = 20
HTTP_USER_AGENT = "Mozilla/5.0 (compatible; investment-dashboard/1.0)"

# ---------------------------------------------------------------------------
# Time / JSON helpers
# ---------------------------------------------------------------------------

def today_kst() -> str:
    return datetime.now(KST).strftime(DATE_FORMAT)


def market_status_kst() -> str:
    now = datetime.now(KST)
    current_minutes = now.hour * 60 + now.minute
    market_open = 9 * 60
    market_close = 15 * 60 + 30
    if market_open <= current_minutes <= market_close:
        return "intraday"
    return "close"


def market_status_for_date(target_date: str) -> str:
    # 과거 거래일을 나중에 보충/재갱신할 때는 실행 시각이 장중이어도 종가 데이터다.
    # 장중 표시는 한국시간 오늘 날짜를 실제로 갱신하는 경우에만 사용한다.
    if target_date == today_kst():
        return market_status_kst()
    return "close"


def is_valid_date_text(value: str) -> bool:
    try:
        datetime.strptime(value, DATE_FORMAT)
        return True
    except ValueError:
        return False


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: Any) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def previous_snapshot(prices: dict[str, Any], before: str | None = None):
    keys = sorted(prices.keys())
    if before:
        keys = [k for k in keys if k < before]
    if not keys:
        return None, None
    return keys[-1], prices[keys[-1]]

# ---------------------------------------------------------------------------
# Market data fetchers
# ---------------------------------------------------------------------------

def fetch_close(
    ticker: str,
    target_date: str,
    lookback_days: int = DEFAULT_LOOKBACK_DAYS,
    retries: int = FETCH_RETRIES,
    retry_delay: float = FETCH_RETRY_DELAY_SECONDS,
):
    """Return the latest available close on or before ``target_date``."""
    start = datetime.strptime(target_date, DATE_FORMAT) - timedelta(days=lookback_days)
    end = datetime.strptime(target_date, DATE_FORMAT)
    last_error = None

    for attempt in range(retries + 1):
        try:
            df = stock.get_market_ohlcv_by_date(start.strftime("%Y%m%d"), end.strftime("%Y%m%d"), ticker)
            if df is None or df.empty:
                last_error = "empty-dataframe"
            else:
                last_idx = df.index[-1]
                actual_date = last_idx.strftime(DATE_FORMAT) if hasattr(last_idx, "strftime") else str(last_idx)[:10]
                close = int(df.iloc[-1]["종가"])
                return actual_date, close, None
        except Exception as exc:
            last_error = repr(exc)

        if attempt < retries:
            time.sleep(retry_delay)

    return None, None, last_error


def fetch_index_history_from_pykrx(
    start_date: str,
    end_date: str,
    ticker: str = KOSPI_INDEX_TICKER,
    retries: int = FETCH_RETRIES,
    retry_delay: float = FETCH_RETRY_DELAY_SECONDS,
):
    """Fetch KOSPI history through pykrx when the endpoint is available."""
    last_error = None
    for attempt in range(retries + 1):
        try:
            getter = getattr(stock, "get_index_ohlcv", None) or getattr(stock, "get_index_ohlcv_by_date", None)
            if getter is None:
                raise AttributeError("pykrx index OHLCV function is unavailable")
            df = getter(start_date.replace("-", ""), end_date.replace("-", ""), ticker)
            if df is None or df.empty:
                last_error = "empty-dataframe"
            else:
                values: dict[str, float] = {}
                for index, row in df.iterrows():
                    date = index.strftime(DATE_FORMAT) if hasattr(index, "strftime") else str(index)[:10]
                    close = row.get("종가")
                    if close is not None:
                        values[date] = round(float(close), 2)
                if values:
                    return values, None
                last_error = "empty-close-values"
        except Exception as exc:
            last_error = repr(exc)
        if attempt < retries:
            time.sleep(retry_delay)
    return {}, last_error


def fetch_index_history_from_naver(start_date: str, end_date: str):
    """Fallback for environments where KRX index endpoints require a login session."""
    start = datetime.strptime(start_date, DATE_FORMAT)
    today = datetime.now(KST).replace(tzinfo=None)
    calendar_days = max(1, (today - start).days)
    count = min(5000, max(180, int(calendar_days * 1.7) + 45))
    url = "https://fchart.stock.naver.com/sise.nhn"
    response = requests.get(
        url,
        params={
            "symbol": "KOSPI",
            "timeframe": "day",
            "count": count,
            "requestType": 0,
        },
        headers={"User-Agent": HTTP_USER_AGENT},
        timeout=HTTP_TIMEOUT_SECONDS,
    )
    response.raise_for_status()

    root = ET.fromstring(response.content)
    values: dict[str, float] = {}
    for item in root.findall(".//item"):
        parts = str(item.attrib.get("data", "")).split("|")
        if len(parts) < 5:
            continue
        raw_date, raw_close = parts[0], parts[4]
        if len(raw_date) != 8:
            continue
        date = f"{raw_date[:4]}-{raw_date[4:6]}-{raw_date[6:8]}"
        if start_date <= date <= end_date:
            values[date] = round(float(raw_close), 2)
    if not values:
        raise ValueError("Naver KOSPI chart returned no values in requested range")
    return values


def fetch_index_history_from_yahoo(start_date: str, end_date: str):
    """Fallback using Yahoo Finance chart data for the KOSPI composite index (^KS11)."""
    start_dt = datetime.strptime(start_date, DATE_FORMAT).replace(tzinfo=KST)
    # Yahoo period2 is exclusive, so include the full end date plus one extra day.
    end_dt = (datetime.strptime(end_date, DATE_FORMAT) + timedelta(days=1)).replace(tzinfo=KST)

    response = requests.get(
        "https://query1.finance.yahoo.com/v8/finance/chart/%5EKS11",
        params={
            "period1": int(start_dt.timestamp()),
            "period2": int(end_dt.timestamp()),
            "interval": "1d",
            "events": "history",
            "includeAdjustedClose": "true",
        },
        headers={
            "User-Agent": HTTP_USER_AGENT,
            "Accept": "application/json,text/plain,*/*",
        },
        timeout=HTTP_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    payload = response.json()
    chart = payload.get("chart") or {}
    if chart.get("error"):
        raise ValueError(f"Yahoo chart error: {chart['error']}")

    results = chart.get("result") or []
    if not results:
        raise ValueError("Yahoo KOSPI chart returned no result")

    result = results[0]
    timestamps = result.get("timestamp") or []
    indicators = result.get("indicators") or {}
    quotes = indicators.get("quote") or []
    closes = quotes[0].get("close") if quotes else []
    closes = closes or []

    values: dict[str, float] = {}
    for timestamp, close in zip(timestamps, closes):
        if timestamp is None or close is None:
            continue
        date = datetime.fromtimestamp(int(timestamp), KST).strftime(DATE_FORMAT)
        if start_date <= date <= end_date:
            values[date] = round(float(close), 2)

    if not values:
        raise ValueError("Yahoo KOSPI chart returned no values in requested range")
    return values


def fetch_index_history(start_date: str, end_date: str, ticker: str = KOSPI_INDEX_TICKER):
    """Fetch KOSPI history with a deterministic fallback chain.

    Source priority is pykrx → Naver fchart → Yahoo Finance.  The fallback is
    intentionally kept here so the workflow does not silently lose KOSPI data
    when a single upstream endpoint changes or requires a session.
    """
    errors: list[str] = []

    values, pykrx_error = fetch_index_history_from_pykrx(start_date, end_date, ticker)
    if values:
        print(f"KOSPI source=pykrx rows={len(values)}")
        return values, None
    errors.append(f"pykrx={pykrx_error}")

    try:
        values = fetch_index_history_from_naver(start_date, end_date)
        print(f"KOSPI source=naver-fchart rows={len(values)}; pykrx failed: {pykrx_error}")
        return values, None
    except Exception as naver_exc:
        errors.append(f"naver={naver_exc!r}")

    try:
        values = fetch_index_history_from_yahoo(start_date, end_date)
        print(f"KOSPI source=yahoo-ks11 rows={len(values)}; earlier sources failed")
        return values, None
    except Exception as yahoo_exc:
        errors.append(f"yahoo={yahoo_exc!r}")

    return {}, "; ".join(errors)


# ---------------------------------------------------------------------------
# KOSPI backfill
# ---------------------------------------------------------------------------

def backfill_kospi_index(prices: dict[str, Any], snapshots: dict[str, Any], through_date: str) -> list[str]:
    stored_dates = sorted({
        date for date in [*prices.keys(), *snapshots.keys()]
        if is_valid_date_text(date) and date <= through_date
    })
    if not stored_dates:
        return []

    history, error = fetch_index_history(stored_dates[0], through_date)
    if not history:
        # Do not silently report a successful workflow when the chart data was not written.
        raise RuntimeError(f"KOSPI index backfill failed: {error}")

    changed: list[str] = []
    for date, close in history.items():
        touched = False
        if date in snapshots and float(snapshots[date].get("kospi", 0) or 0) != close:
            snapshots[date]["kospi"] = close
            touched = True
        if date in prices:
            indices = prices[date].setdefault("indices", {})
            if float(indices.get("KOSPI", 0) or 0) != close:
                indices["KOSPI"] = close
                touched = True
        if touched:
            changed.append(date)

    if changed:
        print(f"updated KOSPI index for {len(changed)} stored dates ({changed[0]} ~ {changed[-1]})")
    return changed


# ---------------------------------------------------------------------------
# Target-date resolution
# ---------------------------------------------------------------------------

def date_range(start_date: str, end_date: str) -> list[str]:
    start = datetime.strptime(start_date, DATE_FORMAT)
    end = datetime.strptime(end_date, DATE_FORMAT)
    dates: list[str] = []

    current = start
    while current <= end:
        dates.append(current.strftime(DATE_FORMAT))
        current += timedelta(days=1)

    return dates


def visible_price_dates(prices: dict[str, Any]) -> list[str]:
    """Return stored dashboard dates that are valid and visible."""
    return sorted(
        date
        for date, snapshot in prices.items()
        if is_valid_date_text(date)
        and isinstance(snapshot, dict)
        and snapshot.get("display", True) is not False
    )


def latest_price_date(prices: dict[str, Any]) -> str | None:
    dates = visible_price_dates(prices)
    return dates[-1] if dates else None


def first_security_ticker(portfolio: dict[str, Any]) -> str | None:
    for item in portfolio.get("securities", []):
        ticker = item.get("ticker")
        if ticker:
            return str(ticker)
    return None


def resolve_latest_market_date(portfolio: dict[str, Any], target_date: str) -> str | None:
    ticker = first_security_ticker(portfolio)

    if not ticker:
        return None

    actual, close, err = fetch_close(ticker, target_date)

    if actual and close is not None:
        return actual

    print(f"WARN latest market date lookup failed for {ticker} {target_date}: {err}")
    return None


def is_actual_trading_date(portfolio: dict[str, Any], target_date: str) -> bool:
    ticker = first_security_ticker(portfolio)

    if not ticker:
        return False

    actual, close, _ = fetch_close(ticker, target_date)

    return actual == target_date and close is not None


def resolve_target_dates(portfolio: dict[str, Any], prices: dict[str, Any], explicit_date: str | None) -> list[str]:
    """Resolve explicit or automatic KRX refresh dates.

    Automatic mode includes missing trading dates and snapshots that still need
    intraday/closing-price reconfirmation.
    """
    if explicit_date:
        return [explicit_date]

    latest_saved = latest_price_date(prices)
    latest_market = resolve_latest_market_date(portfolio, today_kst())

    if not latest_market:
        return []

    if not latest_saved:
        return [latest_market]

    # 가장 최근 저장일이 아직 종가로 확정되지 않은 상태(intraday)라면,
    # 이미 prices에 존재하더라도 다시 갱신 대상에 포함시켜서
    # 장중 재요청 시 최신가로 갱신하거나, 마감 후 요청 시 종가로 확정되게 한다.
    # 저장 시점이 장중이었던 과거 날짜가 남아 있으면 최신 저장일이 아니어도
    # 다시 갱신한다. 예: 다음 거래일 장중에 누락된 전 거래일을 보충한 경우,
    # 전 거래일은 종가로 확정해야 한다.
    refresh_dates = [
        date
        for date, snapshot in prices.items()
        if is_valid_date_text(date)
        and isinstance(snapshot, dict)
        and snapshot.get("display", True) is not False
        and snapshot.get("marketStatus") == "intraday"
    ]
    latest_snapshot = prices.get(latest_saved) or {}
    current_market_status = market_status_kst()

    if latest_snapshot.get("marketStatus") == "intraday" and latest_saved not in refresh_dates:
        refresh_dates.append(latest_saved)
    elif latest_saved == latest_market and latest_saved == today_kst() and current_market_status == "close":
        # 같은 날 장마감 후 자동 실행 시, 오전/장중에 만들어진 스냅샷이
        # 이미 close로 표시되어 있어도 한 번 더 갱신할 수 있게 한다.
        refresh_dates.append(latest_saved)

    stored_dates = visible_price_dates(prices)
    first_saved = stored_dates[0] if stored_dates else latest_saved

    # 최신 저장일 이후뿐 아니라 저장 구간 내부의 누락도 함께 확인한다.
    # 주말은 사전 제외하고, 공휴일/실제 거래일 여부만 KRX 데이터로 확인한다.
    candidates = [
        date
        for date in date_range(first_saved, latest_market)
        if date not in prices
        and datetime.strptime(date, DATE_FORMAT).weekday() < 5
    ]
    missing_dates = [
        date
        for date in candidates
        if is_actual_trading_date(portfolio, date)
    ]

    # A prior local run can leave a hidden, warning-bearing snapshot behind.
    # It is not selectable, so retry it automatically instead of treating the
    # mere presence of its JSON key as a completed market-date update.
    retry_dates = [
        date
        for date, snapshot in prices.items()
        if is_valid_date_text(date)
        and isinstance(snapshot, dict)
        and snapshot.get("display", True) is False
        and snapshot.get("warnings")
        and date <= latest_market
    ]

    return sorted(set(refresh_dates + missing_dates + retry_dates))


# ---------------------------------------------------------------------------
# Portfolio state / performance calculation
# ---------------------------------------------------------------------------

def symbol_key(name: str) -> str:
    return "KODEX200" if name == "KODEX 200" else name


def security_events(portfolio: dict[str, Any]) -> list[dict[str, Any]]:
    events = portfolio.get("securitiesEvents", [])
    return events if isinstance(events, list) else []


def security_valuation_override(portfolio: dict[str, Any], ticker: str, target_date: str) -> int | None:
    for event in security_events(portfolio):
        if str(event.get("ticker", "")) != str(ticker) or str(event.get("date", "")) != target_date:
            continue
        value = int(event.get("valuationPrice", 0) or 0)
        if value > 0:
            return value
    return None


def security_position_state(item: dict[str, Any], target_date: str, portfolio: dict[str, Any]) -> tuple[float, int]:
    qty = float(item.get("qty", 0) or 0)
    cost = int(item.get("cost", 0) or 0)
    ticker = str(item.get("ticker", ""))

    later = sorted(
        (event for event in security_events(portfolio)
         if str(event.get("ticker", "")) == ticker and str(event.get("date", "")) > target_date),
        key=lambda event: str(event.get("date", "")),
        reverse=True,
    )
    for event in later:
        event_qty = max(0.0, float(event.get("qty", 0) or 0))
        amount = max(0, int(event.get("amount", 0) or 0))
        event_type = str(event.get("type", ""))
        if event_type == "buy":
            qty -= event_qty
            cost -= amount
        elif event_type == "sell":
            qty += event_qty
            cost += max(0, int(event.get("costBasis", 0) or 0))

    return max(0.0, qty), max(0, cost)


def securities_cash_for_date(
    target_date: str,
    portfolio: dict[str, Any],
    snapshots: dict[str, Any] | None = None,
) -> int:
    if isinstance(snapshots, dict):
        saved_dates = sorted(
            date for date, item in snapshots.items()
            if isinstance(date, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) and isinstance(item, dict)
        )
        if saved_dates and target_date < saved_dates[-1]:
            allocation = snapshots.get(target_date, {}).get("allocation", {})
            saved_cash = allocation.get("현금") if isinstance(allocation, dict) else None
            if saved_cash is not None:
                return int(saved_cash)

    cash = int(portfolio.get("constants", {}).get("securitiesCash", 0) or 0)
    for event in security_events(portfolio):
        if str(event.get("date", "")) <= target_date:
            continue
        amount = max(0, int(event.get("amount", 0) or 0))
        event_type = str(event.get("type", ""))
        if event_type in {"contribution", "sell"}:
            cash -= amount
        elif event_type in {"withdrawal", "buy"}:
            cash += amount
    return cash


def account1_principal_for_date(target_date: str, portfolio: dict[str, Any]) -> int:
    principal = int(portfolio.get("constants", {}).get("account1Principal", 0) or 0)
    for event in security_events(portfolio):
        if str(event.get("date", "")) <= target_date:
            continue
        amount = max(0, int(event.get("amount", 0) or 0))
        if event.get("type") == "contribution":
            principal -= amount
        elif event.get("type") == "withdrawal":
            principal += amount
    return principal


def is_symbol_chart_target(item: dict[str, Any], target_date: str) -> bool:
    if item.get("chart") is False:
        return False
    chart_from = str(item.get("chartFrom", "") or "")
    return not chart_from or target_date >= chart_from


def init_security_symbols(portfolio: dict[str, Any], target_date: str) -> dict[str, int]:
    symbols: dict[str, int] = {}
    for item in portfolio.get("securities", []):
        if not is_symbol_chart_target(item, target_date):
            continue
        name = item.get("name")
        if not name:
            continue
        symbols.setdefault(symbol_key(str(name)), 0)
    return symbols


def calculate_performance_snapshot(
    target_date: str,
    portfolio: dict[str, Any],
    prices: dict[str, Any],
    snapshots: dict[str, Any],
) -> dict[str, Any]:
    """Build the performance snapshot corresponding to one price snapshot."""
    price_snapshot = prices[target_date]
    securities_prices = price_snapshot.get("securities", {})

    raw_holding_profit = 0
    symbols = init_security_symbols(portfolio, target_date)
    allocation = {"ETF": 0, "개별주식": 0, "현금": securities_cash_for_date(target_date, portfolio, snapshots)}

    for item in portfolio["securities"]:
        ticker = item["ticker"]
        market_price = int(securities_prices.get(ticker, 0))
        qty, cost = security_position_state(item, target_date, portfolio)
        chart_from = str(item.get("chartFrom", "") or "")
        post_close_pending = bool(
            chart_from
            and target_date < chart_from
            and any(
                str(event.get("type", "")) == "buy"
                and str(event.get("ticker", "")) == str(ticker)
                and str(event.get("date", "")) == target_date
                for event in security_events(portfolio)
            )
        )
        price = int(round(cost / qty)) if post_close_pending and qty else market_price
        eval_amount = cost if post_close_pending else int(round(price * qty))
        profit = 0 if post_close_pending else eval_amount - cost
        raw_holding_profit += profit

        if item.get("type") == "ETF":
            allocation["ETF"] += eval_amount
        else:
            allocation["개별주식"] += eval_amount

        if is_symbol_chart_target(item, target_date):
            name = item["name"]
            key = symbol_key(str(name))
            symbols[key] = profit

    prev_keys = [k for k in sorted(snapshots.keys()) if k < target_date]
    prev_raw = int(snapshots[prev_keys[-1]].get("rawHoldingProfit", 0)) if prev_keys else 0
    daily_profit = raw_holding_profit - prev_raw

    account1_principal = account1_principal_for_date(target_date, portfolio)
    cumulative_return = raw_holding_profit / account1_principal * 100 if account1_principal else 0

    return {
        "display": price_snapshot.get("display", True),
        "source": "calculated-current-portfolio",
        "marketStatus": price_snapshot.get("marketStatus", "close"),
        "requestedDate": price_snapshot.get("requestedDate", target_date),
        "actualMarketDate": price_snapshot.get("actualMarketDate", target_date),
        "updatedAtKST": price_snapshot.get("updatedAtKST"),
        "rawHoldingProfit": raw_holding_profit,
        "cumulativeReturn": cumulative_return,
        "dailyProfit": daily_profit,
        "symbols": symbols,
        "allocation": allocation,
    }


# ---------------------------------------------------------------------------
# Per-date update / persistence
# ---------------------------------------------------------------------------

def update_one_date(
    target_date: str,
    portfolio: dict[str, Any],
    prices: dict[str, Any],
    snapshots: dict[str, Any],
    force_display: bool = False,
    no_display: bool = False,
) -> list[str]:
    """Fetch one date, update prices, then rebuild its performance snapshot."""
    prev_key, prev = previous_snapshot(prices, before=target_date)
    securities, pension, warnings, source_dates = {}, {}, [], {}

    manual_valuation_used = False
    for item in portfolio["securities"]:
        ticker = item["ticker"]
        valuation_override = security_valuation_override(portfolio, ticker, target_date)
        if valuation_override is not None:
            securities[ticker] = int(valuation_override)
            source_dates[f"SEC:{ticker}"] = target_date
            manual_valuation_used = True
            continue

        actual, close, err = fetch_close(ticker, target_date)

        actual_date = str(actual or target_date)
        if close is None:
            fallback = prev.get("securities", {}).get(ticker) if prev else None

            if fallback is None:
                warnings.append(f"SEC {ticker}: 조회 실패 및 직전값 없음: {err}")
                continue

            securities[ticker] = int(fallback)
            warnings.append(f"SEC {ticker}: 조회 실패, 직전 스냅샷 {prev_key} 값 {fallback} 사용: {err}")
            source_dates[f"SEC:{ticker}"] = str(prev.get("priceSourceDates", {}).get(f"SEC:{ticker}") or prev.get("actualMarketDate") or prev_key)
        else:
            securities[ticker] = int(close)
            source_dates[f"SEC:{ticker}"] = actual_date
            if actual_date != target_date:
                warnings.append(f"SEC {ticker}: {target_date} 종가를 확인하지 못해 {actual_date} 종가를 보류값으로 저장했습니다.")

    for item in portfolio["pension"]:
        ticker = item["ticker"]
        actual, close, err = fetch_close(ticker, target_date)

        actual_date = str(actual or target_date)
        if close is None:
            fallback = prev.get("pension", {}).get(ticker) if prev else None

            if fallback is None:
                warnings.append(f"PEN {ticker}: 조회 실패 및 직전값 없음: {err}")
                continue

            pension[ticker] = int(fallback)
            warnings.append(f"PEN {ticker}: 조회 실패, 직전 스냅샷 {prev_key} 값 {fallback} 사용: {err}")
            source_dates[f"PEN:{ticker}"] = str(prev.get("priceSourceDates", {}).get(f"PEN:{ticker}") or prev.get("actualMarketDate") or prev_key)
        else:
            pension[ticker] = int(close)
            source_dates[f"PEN:{ticker}"] = actual_date
            if actual_date != target_date:
                warnings.append(f"PEN {ticker}: {target_date} 종가를 확인하지 못해 {actual_date} 종가를 보류값으로 저장했습니다.")

    pension["cash"] = int(prev.get("pension", {}).get("cash", 0)) if prev else 0
    actual_date = min(source_dates.values()) if source_dates else target_date

    # A date with any stale/missing symbol must not become a selectable dashboard close.
    display = not warnings

    if no_display:
        display = False

    if force_display and not warnings:
        display = True

    status = market_status_for_date(target_date)
    updated_at = datetime.now(KST).isoformat(timespec="seconds")

    prices[target_date] = {
        "display": display,
        "source": "pykrx-github-actions+nxt-valuation" if manual_valuation_used else "pykrx-github-actions",
        "marketStatus": status,
        "requestedDate": target_date,
        "actualMarketDate": actual_date,
        "updatedAtKST": updated_at,
        "priceSourceDates": source_dates,
        "securities": securities,
        "pension": pension,
    }

    if warnings:
        prices[target_date]["warnings"] = warnings

    snapshots[target_date] = calculate_performance_snapshot(target_date, portfolio, prices, snapshots)

    if warnings:
        print(f"WARNINGS for {target_date}:")
        for warning in warnings:
            print("-", warning)

    print(
        "updated prices and performance snapshots "
        f"for {target_date} actualMarketDate={actual_date} marketStatus={status}"
    )

    return warnings

# ---------------------------------------------------------------------------
# CLI orchestration
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="KRX 가격, 성과 스냅샷, KOSPI 지수를 갱신합니다.",
    )
    parser.add_argument(
        "--date",
        default="",
        help=(
            "YYYY-MM-DD. 지정하면 해당 거래일의 종목 가격·성과를 갱신하고 지정일까지 저장된 KOSPI 구간의 "
            "누락·정정값을 backfill. 비워두면 누락 거래일 보완 및 장중 저장분의 종가 재확정 대상을 자동 갱신."
        ),
    )
    parser.add_argument(
        "--force-display",
        action="store_true",
        help="갱신 날짜를 dashboard 표시 대상으로 강제합니다.",
    )
    parser.add_argument(
        "--no-display",
        action="store_true",
        help="갱신 날짜를 dashboard 비표시 대상으로 저장합니다.",
    )
    return parser.parse_args()


def load_dashboard_data() -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Load the three JSON documents required by the updater."""
    portfolio = load_json(PORTFOLIO_PATH)
    prices = load_json(PRICES_PATH)
    snapshots = load_json(SNAPSHOTS_PATH) if SNAPSHOTS_PATH.exists() else {}
    return portfolio, prices, snapshots


def save_dashboard_data(prices: dict[str, Any], snapshots: dict[str, Any]) -> None:
    """Persist only the generated KRX data files managed by this script."""
    save_json(PRICES_PATH, dict(sorted(prices.items())))
    save_json(SNAPSHOTS_PATH, dict(sorted(snapshots.items())))


def main() -> int:
    args = parse_args()
    explicit_date = str(args.date or "").strip()

    if explicit_date and not is_valid_date_text(explicit_date):
        raise ValueError("--date는 YYYY-MM-DD 형식이어야 합니다.")

    portfolio, prices, snapshots = load_dashboard_data()

    if explicit_date and not is_actual_trading_date(portfolio, explicit_date):
        raise ValueError(
            f"--date {explicit_date}는 KRX 거래일이 아니거나 해당 날짜 종가를 확인할 수 없습니다."
        )

    target_dates = resolve_target_dates(portfolio, prices, explicit_date or None)

    if target_dates:
        print("target dates: " + ", ".join(target_dates))
    else:
        print("No missing trading dates to update. KOSPI index backfill will still be checked.")

    all_warnings: list[str] = []

    for target_date in target_dates:
        warnings = update_one_date(
            target_date,
            portfolio,
            prices,
            snapshots,
            force_display=args.force_display,
            no_display=args.no_display,
        )
        all_warnings.extend(warnings)

    kospi_through = explicit_date or today_kst()
    kospi_changed = backfill_kospi_index(prices, snapshots, kospi_through)

    if not target_dates and not kospi_changed:
        print("No price, snapshot, or KOSPI index changes to save.")
        return 0

    save_dashboard_data(prices, snapshots)

    if all_warnings:
        print("WARNINGS:")
        for warning in all_warnings:
            print("-", warning)

    if target_dates:
        print("updated target dates: " + ", ".join(target_dates))
    if kospi_changed:
        print(f"updated KOSPI dates: {len(kospi_changed)}")
    return 1 if all_warnings else 0


if __name__ == "__main__":
    raise SystemExit(main())
